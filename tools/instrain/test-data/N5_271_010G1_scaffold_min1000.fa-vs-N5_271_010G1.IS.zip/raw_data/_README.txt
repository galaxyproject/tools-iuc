The data in this folder can be easily accessed using the inStrain python API.
For information on how this is done, see the inStrain documentaion at https://instrain.readthedocs.io/en/latest/
